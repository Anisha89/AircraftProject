export class Gse {
id:number;
imgname:string;
sno:string;
gseno:string;
portno:string;
gdm:string;
description:string;
date_created:any;
}
