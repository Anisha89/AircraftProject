export class Spare {
    idspare:number;
    imgname:string;
    seqno:string;
    partno:string;
    oem:string;
    description:string;
    date_created:any;

}
