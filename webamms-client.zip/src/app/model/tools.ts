export class Tools {
    id:number;
    imgname:string;
    sno:string;
    toolsno:string;
    partno:string;
    gdm:string;
    description:string;
    date_created:any;

}
