export class Consumable {
    id:number;
    imgname:string;
    sno:string;
    consumableno:string;
    partno:string;
    oem:string;
    description:string;
    date_created:any;
    
  }