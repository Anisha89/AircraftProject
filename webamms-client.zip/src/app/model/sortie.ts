export class Sortie {
     id:number;
     tail:string;
     src_from:string;
     dst_no:string;
     sortie_no: string;
     date_flown:number;
     str_date_flown:string;
     up_time_hrs:string;
     down_time_hrs:string;
     port_hrs:string;
     stbd_hrs:string;
     aarc:string;
     apu_hrs:string;
     apuc_hrs:string;
     apu_cycle:string;
     apuc_cycle:string;
     flight_cycle:string;
     after_flight_log:string;
     repair_log:string;
     aircraft_status:string;
     aircraft:String;
     file:string;
}
