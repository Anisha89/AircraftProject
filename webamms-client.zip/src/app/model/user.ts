export class User {
    id:number;
    emailId:string;
    userName:string;
    password:string;
    imgname:string;
    status:string;
    date_created:any;
    time_updated:any;
    dateformat:any;
    timeformat:any;
    reset_Token:any;
    roll:any;
constructor(){}
}
