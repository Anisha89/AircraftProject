export class Servicehistory {
    [x: string]: any;
    id:number;
    sno:number;
    service:string;
    servicedue:any;
    status:any;
    startdate:any;
    str_startdate:string
    enddate:any;
    str_enddate:string;
    lastservice:any;
    str_lastservice:string
    alert:number;
    servicecompleted:string;
    concessionnates:string;
    date_created:any;
    nextservice:any;
    str_nextservice:string;
    aircraft:string;
}
