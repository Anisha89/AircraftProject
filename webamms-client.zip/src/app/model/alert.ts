export class Alert {
    id:number
    servicetype:string
    aircraft:string
    servicedue:any
}

