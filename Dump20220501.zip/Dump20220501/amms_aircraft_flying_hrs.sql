-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: amms
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `aircraft_flying_hrs`
--

LOCK TABLES `aircraft_flying_hrs` WRITE;
/*!40000 ALTER TABLE `aircraft_flying_hrs` DISABLE KEYS */;
INSERT INTO `aircraft_flying_hrs` VALUES (10,'11:05','log','KW-3554','Avaliable','11:05','11:06','11:06','11:06',1651363200,'11:06','Bangalore','Doc1.pdf',24,'11:05','log','101','Madurai','11:05','11:05'),(9,'11:04','log','KW-3554','Avaliable','11:05','11:03','11:08','11:03',1651363200,'11:03','Bangalore','Doc1.pdf',23,'11:03','log','101','chennai','11:03','11:03'),(7,'18:55','log','KW-3554','AOG','18:55','18:55','18:55','18:55',1651017600,'18:55','chennai','Doc1.pdf',21,'18:55','log','101','Bangalore','18:55','18:55'),(8,'11:02','log','KW-3554','Avaliable','11:02','11:02','11:02','11:02',1651363200,'12:01','chennai','Doc1.pdf',22,'11:01','log','101','Bangalore','11:02','11:02'),(11,'11:07','log','KW-3554','Avaliable','11:07','11:07','11:07','11:07',1651363200,'11:06','Bangalore','Doc1.pdf',25,'11:07','log','101','chennai','11:07','11:06'),(12,'11:08','log','KW-3554','Avaliable','11:08','11:08','11:08','11:08',1651363200,'11:08','chennai','Doc1.pdf',26,'11:08','log','101','Bangalore','11:08','11:07');
/*!40000 ALTER TABLE `aircraft_flying_hrs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-01 12:30:09
