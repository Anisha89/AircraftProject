-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: amms
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `tools`
--

LOCK TABLES `tools` WRITE;
/*!40000 ALTER TABLE `tools` DISABLE KEYS */;
INSERT INTO `tools` VALUES (6,1651085171025,'Bottle of nitrogen with pressure gaugeor compressed air source with pressuregauge','oem','Tools_6_tool5.jpg','P106','106','T106'),(2,1650438041086,'Pressure gauge with scale up to 3 psiand accuracy of Â± 0.05 psi','oem','Tools_2_tool2.jpg','P102','102','T102'),(3,1650438420884,'Dynamometer','oem ','Tools_3_tool3.jpg','P103','103','T103'),(4,1650438513283,'Wiper cloth','oem','Tools_4_tool4.jpg,Tools_4_tool5.jpg,Tools_4_tool1.png,Tools_4_tool2.jpg,Tools_4_tool4.jpg,Tools_4_tool4.jpg,Tools_4_tool1.png4_tool4.jpg','P104','104','T104'),(5,1650439305892,'Tee AS1039W040404 or equivalent','oem','Tools_5_tool5.jpg','P105','105','T105'),(7,1651085293517,'Digital thermometer - range as much as 91 Â± 3Â°C (195 Â± 5Â°F)','oem','Tools_7_tool1.png','P107','107','T107'),(1,1651085293517,'Pressure gauge, 3500 psig','oem','Tools_7_tool1.png','P101','101','T101'),(8,1651085293517,'Stiff-Bristle Brush Brush','oem','Tools_7_tool1.png','P108','108','T108'),(9,1651085293517,'Click-Type, Wrench - Torque','oem','Tools_7_tool1.png','P109','109','T109'),(10,1651085293517,'Pacific Scientific Cradle','oem','Tools_7_tool1.png','P110','110','T110'),(11,1651085293517,'Ultrasonic Bath','oem','Tools_7_tool1.png','P110','110','T110'),(12,1651085293517,'Workstand','oem','Tools_7_tool1.png','P110','110','T110'),(13,1651085293517,'Cable Tensiometer','oem','Tools_7_tool1.png','P110','110','T110'),(14,1651085293517,'Torque Wrench','oem','Tools_7_tool1.png','P110','110','T110'),(15,1651085293517,'Thermogun','oem','Tools_7_tool1.png','P110','110','T110');
/*!40000 ALTER TABLE `tools` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-01 12:30:07
