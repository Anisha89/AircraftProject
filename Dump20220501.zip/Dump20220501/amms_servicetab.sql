-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: amms
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `servicetab`
--

LOCK TABLES `servicetab` WRITE;
/*!40000 ALTER TABLE `servicetab` DISABLE KEYS */;
INSERT INTO `servicetab` VALUES (1,'AMMTASK21-26-08-960-801-A/200','1','3',1650780269978,'Discard Exhaust Hoses of the Electronic Bay Compartment','ALL','3','101','21-26-08-960-001-A00','3','3','trade','DIS'),(2,'AMMTASK24-22-01-900-801-A/200','2','3',1650780269978,'Restore APU Generato','ALL','3','102','24-22-01-900-001-A00','3','3','trade','RST'),(3,'AMMTASK24-31-01-900-801-A/200','3','3',1650780269978,'Restore Main Generator P/N 30086-011','ALL','3','103','24-31-01-900-001-A01','3','3','trade','RST'),(4,'AMMTASK26-24-01-700-801-A/500','4','3',1650780269978,' Perform Hydrostatic Test of Portable Fire Extinguishing Bottles Applicable to P/N: 466090, 100-9750, and 30H673 ','ALL','3','104','26-24-01-720-001-A00','3','3','trade','FNC'),(5,'AMMTASK26-24-01-960-801-A/200\",','5','3',1650780269978,' Discard Portable Fire Extinguishing Bottles Applicable to P/N RT-A1200 NOTE: From the manufacturing date.','ALL','3','105','26-24-01-960-001-A00','3','3','trade','DIS'),(6,'AMMTASK26-24-01-700-801-A/500','6','3,1,2,4,5',1650780269978,'Service Horizontal Stabilizer Actuator and Check for leakage','ALL','3,4,5,2,1','106','27-40-02-610-001-A00','3,1,2,4,5','3,1,2,4,5','trade','SVC'),(7,'AMMTASK24-31-01-900-801-A/200','7','3',1650780269978,'Restore Main Generator P/N 30086-011  ','ALL','3','107','24-31-01-900-001-A01','3','3','trade','RST'),(8,'AMMTASK26-24-01-700-801-A/500\",','8','3',1650780269978,'Perform Hydrostatic Test of Portable Fire Extinguishing Bottles Applicable to P/N: 466090, 100-9750, and 30H673  ','ALL','3','108','26-24-01-720-001-A00','3','3','trade','FNC'),(9,'AMMTASK26-24-01-960-801-A/200','9','3',1650780269978,'Discard Portable Fire Extinguishing Bottles Applicable to P/N RT-A1200 NOTE: From the manufacturing date','ALL','3','109','26-24-01-960-001-A00','3','3','trade','DIS'),(10,'AMMTASK27-40-02-600-801-A/300','10','3',1650780269978,'Service Horizontal Stabilizer Actuator and Check for leakage','ALL','3','110','27-40-02-610-001-A00','3','3','trade','SVC'),(11,'AMMTASK28-23-04-700-801-A/500','11','3',1650780269978,'Functionally Check Wing Tanks Vent/Relief Valves  ','ALL','3','111','28-23-04-720-801-A00','3','3','trade','FCN'),(12,'AMMTASK28-23-10-700-801-A/500','12','3,1,2,4,5',1650780269978,'Operationally Check Pilot Line Check Valve','ALL','3,4,5,2,1','112','28-23-10-710-801-A00','3,1,2,4,5','3,1,2,4,5','trade','OPC'),(13,'AMMTASK28-51-10-200-801-A/600','13','3',1650780269978,'Inspect (General Visual) AAR Probe Flame Arrestor for inter-nal blockage and/or damage.  ','ALL','3','113','28-51-01-212-002-A00','3','3','trade','GVI'),(14,'AMMTASK29-10-04-700-801-A/500','14','3',1650780269978,'Replace EMDP Brushes  ','ALL','3','114','29-10-04-710-001-A00','3','3','trade','DIS'),(15,'AMMTASK32-10-01-900-801-A/200','14','3,1,2,4,5',1650780269978,'Restore Main Landing Gear (MLG) Leg Strut Assy. ','ALL','3,4,5,2,1','115','32-10-01-900-001-A00\",','3,1,2,4,5','3,1,2,4,5','trade','RST');
/*!40000 ALTER TABLE `servicetab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-01 12:30:05
