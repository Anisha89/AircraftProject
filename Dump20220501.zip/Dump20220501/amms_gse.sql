-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: amms
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `gse`
--

LOCK TABLES `gse` WRITE;
/*!40000 ALTER TABLE `gse` DISABLE KEYS */;
INSERT INTO `gse` VALUES (1,1650439833112,'Plumb, aircraft leveling','oem','GSE100','Gse_1_GSE1.jpg','P100','1'),(2,1650439894758,'Tow bar-Aircraft','oem','GSE101','Gse_2_GSE2.jpg','P101','2'),(3,1650439946535,'Wheel Chock','oem','GSE103','Gse_3_GSE3.jpg','P103','3'),(4,1650440079761,'Tool- drain valve Removal/Installation','oem','GSE104','Gse_4_GSE4.jpg','P104','4'),(5,1650440125033,'Regulator-Nitrogen Servicing','oem','GSE105','Gse_5_gse5.jpg','P105','5'),(6,1650440125033,'Gauge-Tire Pressure','oem','GSE106','Gse_5_gse5.jpg','P106','6'),(7,1650440125033,'Pressure regulator valve with pressuregauges','oem','GSE107','Gse_5_gse5.jpg','P107','7'),(8,1650440125033,'Pressure regulator valve with pressuregauges','oem','GSE108','Gse_5_gse5.jpg','P108','8'),(9,1650440125033,'Kit- Stall warning','oem','GSE109','Gse_5_gse5.jpg','P109','9'),(10,1650440125033,'Converter ,USB To DB25','oem','GSE110','Gse_5_gse5.jpg','P110','10'),(11,1650440125033,'TCAS Software Part Number Tool','oem','GSE111','Gse_5_gse5.jpg','P111','11'),(12,1650440125033,'Wrist strap','oem','GSE112','Gse_5_gse5.jpg','P112','12'),(13,1650440125033,'Wrench Set-INSTL/RMV,Pylon BSHG','oem','GSE113','Gse_5_gse5.jpg','P113','13'),(14,1650440125033,'Flap Breakout Box','oem','GSE114','Gse_5_gse5.jpg','P114','14'),(15,1650440125033,'Portable Data Loader-(PDL-615)','oem','GSE115','Gse_5_gse5.jpg','P115','1');
/*!40000 ALTER TABLE `gse` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-01 12:30:08
