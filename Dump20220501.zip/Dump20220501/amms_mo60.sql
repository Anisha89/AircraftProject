-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: amms
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `mo60`
--

LOCK TABLES `mo60` WRITE;
/*!40000 ALTER TABLE `mo60` DISABLE KEYS */;
INSERT INTO `mo60` VALUES (1,'AMMTASK21-26-08-960-801-A/200','1','1,2',1650820626942,'Service Horizontal Stabilizer Actuator and Check for leakage','ALL','1,2,3,4,5','101','60Mo','21-26-08-960-001-A00','2,3','2,3','trade','DIS'),(5,'AMMTASK26-24-01-960-801-A/200','5','1,2',1650820626942,'Discard Portable Fire Extinguishing Bottles Applicable to P/N RT-A1200 NOTE: From the manufacturing date.','ALL','1,2,3,4,5','105','60Mo','26-24-01-960-001-A00','2,3','2,3','trade','GVI'),(2,'AMMTASK24-22-01-900-801-A/200','2','1,2',1650820626942,'Restore Main Generator P/N 30086-011\',','ALL','1,2,3,4,5','102','60Mo','24-22-01-900-001-A00','2,3','2,3','trade','SVC'),(3,'AMMTASK24-31-01-900-801-A/200','3','1,2',1650820626942,'Restore APU Generato','ALL','1,2,3,4,5','103','60Mo','24-31-01-900-001-A01','2,3','2,3','trade','RST'),(6,'AMMTASK21-26-08-960-801-A/200','6','1,2',1650820626942,'Service Horizontal Stabilizer Actuator and Check for leakage','ALL','1,2,3,4,5','106','60Mo','27-40-02-610-001-A00\',','2,3','2,3','trade','DIS'),(7,'AMMTASK26-24-01-700-801-A/500\',','7','1,2',1650820626942,'\'Service Horizontal Stabilizer Actuator and Check for leakage','ALL','1,2,3,4,5','107','60Mo','24-31-01-900-001-A01','2,3','2,3','trade','DIS'),(8,'AMMTASK24-31-01-900-801-A/200','8','1,2',1650820626942,'Restore Main Generator P/N 30086-011','ALL','1,2,3,4,5','108','60Mo','26-24-01-720-001-A00','2,3','2,3','trade','RST'),(9,'AMMTASK26-24-01-700-801-A/500\\\",\',','9','1,2',1650820626942,'Perform Hydrostatic Test of Portable Fire Extinguishing Bottles Applicable to P/N: 466090, 100-9750','ALL','1,2,3,4,5','109','60Mo','28-51-01-212-002-A00','2,3','2,3','trade','RST'),(10,'AMMTASK27-40-02-600-801-A/300','10','1,2',1650820626942,'\'Discard Portable Fire Extinguishing Bottles Applicable to P/N RT-A1200 NOTE: From the manufacturing date0269978','ALL','1,2,3,4,5','110','60Mo','26-24-01-960-001-A00','2,3','2,3','trade','FNC'),(11,'AMMTASK21-26-08-960-801-A/200','11','1,2',1650820626942,'Replace EMDP Brushes ','ALL','1,2,3,4,5','111','60Mo','27-40-02-610-001-A00','2,3','2,3','trade','DIS'),(12,'AMMTASK28-23-04-700-801-A/500','12','1,2',1650820626942,'Service Horizontal Stabilizer Actuator and Check for leakage\',','ALL','1,2,3,4,5','112','60Mo','28-23-04-720-801-A00','2,3','2,3','trade','SVC'),(13,'AMMTASK28-23-10-700-801-A/500','13','1,2',1650820626942,'Functionally Check Wing Tanks Vent/Relief Valves  ','ALL','1,2,3,4,5','113','60Mo','28-23-10-710-801-A00\',','2,3','2,3','trade','RST'),(14,'AMMTASK28-51-10-200-801-A/600\',','14','1,2',1650820626942,'Operationally Check Pilot Line Check Valve','ALL','1,2,3,4,5','114','60Mo','28-23-10-710-801-A00','2,3','2,3','trade','FNC'),(15,'AMMTASK32-10-01-900-801-A/200','15','1,2',1650820626942,'Restore Main Landing Gear (MLG) Leg Strut Assy','ALL','1,2,3,4,5','115','60Mo','32-10-01-900-001-A00\",\',','2,3','2,3','trade','GVI');
/*!40000 ALTER TABLE `mo60` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-01 12:30:07
