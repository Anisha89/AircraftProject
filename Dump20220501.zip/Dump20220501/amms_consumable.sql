-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: amms
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `consumable`
--

LOCK TABLES `consumable` WRITE;
/*!40000 ALTER TABLE `consumable` DISABLE KEYS */;
INSERT INTO `consumable` VALUES (1,'C101',1650440241150,'MEP 09-060 Corrosion-Inhibiting Compound (CA-1000)','Consumable_1_112701_1ed4ddb94d0bcbd1_969X727.jpg','oem','P101','101'),(2,'C102',1650440447968,'MEP 09-075 Corrosion-Inhibiting Compound (COR-BAN 27L)','Consumable_2_images (4).jpg','oem','P102','102'),(3,'C103',1650440491995,'MS24665-153 Cotter pin','Consumable_3_gse5.jpg','oem','P103','103'),(4,'C104',1650440518321,'Leak Tec No. 160X MIL-L-25567 or equivalent','Consumable_4_images (9).jpg','oem','p104','104'),(5,'C105',1650440564575,'Molykote DC-33 Light Lubricant','Consumable_5_alogo.png','oem','p105','105'),(6,'C106',1650440241150,'O-ring 28-14-00','Consumable_1_112701_1ed4ddb94d0bcbd1_969X727.jpg','oem','P106','106'),(7,'C107',1650440447968,'Leak Tec No. 16-OX MIL-L-25567 or equivalent','Consumable_2_images (4).jpg','oem','P107','107'),(8,'C108',1650440491995,'Leak Tec No. 16 MIL-L-25567 or equivalent','Consumable_3_gse5.jpg','oem','P108','108'),(9,'C109',1650440518321,'MS20995C20 Lock wire','Consumable_4_images (9).jpg','oem','p109','109'),(10,'C110',1650440564575,'Type I Loctite 221 (or equivalent)','Consumable_5_alogo.png','oem','p110','110'),(11,'C111',1650440241150,'Adhesive','Consumable_1_112701_1ed4ddb94d0bcbd1_969X727.jpg','oem','P111','111'),(12,'C112',1650440447968,'ASTM-D740 Methyl ethyl ketone (MEK)','Consumable_2_images (4).jpg','oem','P112','112'),(13,'C113',1650440491995,'Liquid Sodium Hypochlorite (10%), Acetic Acid (Vinegar), Alcohol','Consumable_3_gse5.jpg','oem','P113','113'),(14,'C114',1650440518321,'Brayco Micronic 762 Gear oil','Consumable_4_images (9).jpg','oem','p114','114'),(15,'C115',1650440564575,'O-ring CMM 27-41-07 / IPL 27-41-07-01-25','Consumable_5_alogo.png','oem','p115','115');
/*!40000 ALTER TABLE `consumable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-01 12:30:07
