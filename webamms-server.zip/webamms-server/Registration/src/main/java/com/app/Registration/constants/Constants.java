package com.app.Registration.constants;

public class Constants {
	//public static String concessionPath = "E:\\Workspace\\anisha\\amms-testing\\webamms-server\\src\\main\\webapp\\pdf\\";
	//public static String concessionPath ="C:\\Users\\HP\\Desktop\\Amms\\webamms-server\\Registration\\src\\main\\webapp\\pdf\\";
	public static String ImageUploadingPath ="C:\\Users\\HP\\Desktop\\Amms\\webamms-server\\Registration\\src\\main\\webapp\\uploads";
	public static String pdfUploadingPath ="C:\\Users\\HP\\Desktop\\Amms\\webamms-server\\Registration\\src\\main\\webapp\\pdf\\";


}
//

//public static String concessionPath ="C:\\Users\\HP\\Desktop\\Amms\\webamms-server\\Registration\\src\\main\\webapp\\uploads";
//
//public static String consumablePath ="D:\\Ksix-project\\webamms-server\\src\\main\\webapp\\uploadconsumable\\";
//
//public static String gsePath ="D:\\Ksix-project\\webamms-server\\src\\main\\webapp\\uploadgse\\";
//
//public static String gsePath2 ="D:\\Ksix-project\\webamms-server\\src\\main\\webapp\\uploads\\";
//
//public static String ImageUploadingPath ="C:\\Users\\HP\\Desktop\\Amms\\webamms-server\\Registration\\src\\main\\webapp\\uploads";
